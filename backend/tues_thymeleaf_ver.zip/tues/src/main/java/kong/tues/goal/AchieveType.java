package kong.tues.goal;

public enum AchieveType {
    TIME, COUNT, BASIC;
}
