package kong.tues.member.exception;

import kong.tues.commons.exception.BusinessException;

public class MemberNotFoundException extends BusinessException {
}
