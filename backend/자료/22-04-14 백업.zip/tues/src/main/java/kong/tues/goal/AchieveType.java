package kong.tues.goal;

public enum AchieveType {
    WAKE, TIME, COUNT, BASIC;
}
