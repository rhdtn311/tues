package kong.tues.member;

public class SessionConst {
    public static final String LOGIN_MEMBER = "loginMember";
}
