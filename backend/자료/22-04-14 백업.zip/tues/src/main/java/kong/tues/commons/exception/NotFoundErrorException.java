package kong.tues.commons.exception;

public class NotFoundErrorException extends BusinessException {
}
