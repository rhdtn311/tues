package kong.tues.goal.exception;

import kong.tues.commons.exception.BusinessException;

public class GoalTypeDupException extends BusinessException {
}
