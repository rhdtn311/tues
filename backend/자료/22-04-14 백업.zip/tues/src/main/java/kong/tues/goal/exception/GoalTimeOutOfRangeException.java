package kong.tues.goal.exception;

public class GoalTimeOutOfRangeException extends RuntimeException{
}
