package kong.tues.goal;

public enum GoalType {

    A, B, C, D, E, F, G, H, I, J, OTHER;
}
