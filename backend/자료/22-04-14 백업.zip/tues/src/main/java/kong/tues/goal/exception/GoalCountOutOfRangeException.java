package kong.tues.goal.exception;

public class GoalCountOutOfRangeException extends RuntimeException {
}
