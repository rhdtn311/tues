package kong.tues.member.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QMember is a Querydsl query type for Member
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMember extends EntityPathBase<Member> {

    private static final long serialVersionUID = -47672354L;

    public static final QMember member = new QMember("member1");

    public final ListPath<kong.tues.accessTime.domain.AccessTime, kong.tues.accessTime.domain.QAccessTime> accessTime = this.<kong.tues.accessTime.domain.AccessTime, kong.tues.accessTime.domain.QAccessTime>createList("accessTime", kong.tues.accessTime.domain.AccessTime.class, kong.tues.accessTime.domain.QAccessTime.class, PathInits.DIRECT2);

    public final ListPath<kong.tues.achievement.domain.Achievement, kong.tues.achievement.domain.QAchievement> achievement = this.<kong.tues.achievement.domain.Achievement, kong.tues.achievement.domain.QAchievement>createList("achievement", kong.tues.achievement.domain.Achievement.class, kong.tues.achievement.domain.QAchievement.class, PathInits.DIRECT2);

    public final ListPath<kong.tues.goal.dailyGoal.domain.DailyGoal, kong.tues.goal.dailyGoal.domain.QDailyGoal> dailyGoal = this.<kong.tues.goal.dailyGoal.domain.DailyGoal, kong.tues.goal.dailyGoal.domain.QDailyGoal>createList("dailyGoal", kong.tues.goal.dailyGoal.domain.DailyGoal.class, kong.tues.goal.dailyGoal.domain.QDailyGoal.class, PathInits.DIRECT2);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath loginId = createString("loginId");

    public final StringPath mail = createString("mail");

    public final ListPath<kong.tues.goal.mothlyGoal.domain.MonthlyGoal, kong.tues.goal.mothlyGoal.domain.QMonthlyGoal> monthlyGoal = this.<kong.tues.goal.mothlyGoal.domain.MonthlyGoal, kong.tues.goal.mothlyGoal.domain.QMonthlyGoal>createList("monthlyGoal", kong.tues.goal.mothlyGoal.domain.MonthlyGoal.class, kong.tues.goal.mothlyGoal.domain.QMonthlyGoal.class, PathInits.DIRECT2);

    public final StringPath password = createString("password");

    public QMember(String variable) {
        super(Member.class, forVariable(variable));
    }

    public QMember(Path<? extends Member> path) {
        super(path.getType(), path.getMetadata());
    }

    public QMember(PathMetadata metadata) {
        super(Member.class, metadata);
    }

}

