package kong.tues.accessTime.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QAccessTime is a Querydsl query type for AccessTime
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QAccessTime extends EntityPathBase<AccessTime> {

    private static final long serialVersionUID = 881064588L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QAccessTime accessTime = new QAccessTime("accessTime");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final kong.tues.member.domain.QMember member;

    public final TimePath<java.time.LocalTime> time = createTime("time", java.time.LocalTime.class);

    public QAccessTime(String variable) {
        this(AccessTime.class, forVariable(variable), INITS);
    }

    public QAccessTime(Path<? extends AccessTime> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QAccessTime(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QAccessTime(PathMetadata metadata, PathInits inits) {
        this(AccessTime.class, metadata, inits);
    }

    public QAccessTime(Class<? extends AccessTime> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.member = inits.isInitialized("member") ? new kong.tues.member.domain.QMember(forProperty("member")) : null;
    }

}

