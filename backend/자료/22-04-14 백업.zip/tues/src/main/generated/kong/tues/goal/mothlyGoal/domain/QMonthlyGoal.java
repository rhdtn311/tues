package kong.tues.goal.mothlyGoal.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QMonthlyGoal is a Querydsl query type for MonthlyGoal
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMonthlyGoal extends EntityPathBase<MonthlyGoal> {

    private static final long serialVersionUID = 204961025L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QMonthlyGoal monthlyGoal = new QMonthlyGoal("monthlyGoal");

    public final EnumPath<kong.tues.goal.AchieveType> achieveType = createEnum("achieveType", kong.tues.goal.AchieveType.class);

    public final StringPath content = createString("content");

    public final DatePath<java.time.LocalDate> date = createDate("date", java.time.LocalDate.class);

    public final NumberPath<Integer> goalCount = createNumber("goalCount", Integer.class);

    public final NumberPath<Integer> goalCountQuota = createNumber("goalCountQuota", Integer.class);

    public final NumberPath<Integer> goalTime = createNumber("goalTime", Integer.class);

    public final NumberPath<Integer> goalTimeQuota = createNumber("goalTimeQuota", Integer.class);

    public final EnumPath<kong.tues.goal.GoalType> goalType = createEnum("goalType", kong.tues.goal.GoalType.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final kong.tues.member.domain.QMember member;

    public final StringPath name = createString("name");

    public final BooleanPath success = createBoolean("success");

    public final TimePath<java.time.LocalTime> wakeUpTime = createTime("wakeUpTime", java.time.LocalTime.class);

    public QMonthlyGoal(String variable) {
        this(MonthlyGoal.class, forVariable(variable), INITS);
    }

    public QMonthlyGoal(Path<? extends MonthlyGoal> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QMonthlyGoal(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QMonthlyGoal(PathMetadata metadata, PathInits inits) {
        this(MonthlyGoal.class, metadata, inits);
    }

    public QMonthlyGoal(Class<? extends MonthlyGoal> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.member = inits.isInitialized("member") ? new kong.tues.member.domain.QMember(forProperty("member")) : null;
    }

}

